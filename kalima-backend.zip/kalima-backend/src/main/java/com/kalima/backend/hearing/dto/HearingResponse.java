package com.kalima.backend.hearing.dto;

import com.kalima.backend.casefile.dto.PartySummary;

import java.time.LocalDateTime;
import java.util.UUID;

public record HearingResponse(
        UUID id,
        UUID caseId,
        LocalDateTime hearingDate,
        String courtName,
        String chamber,
        String result,
        String notes,
        LocalDateTime nextHearingDate,
        PartySummary createdBy,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
