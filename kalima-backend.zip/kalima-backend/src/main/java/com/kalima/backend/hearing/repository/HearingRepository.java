package com.kalima.backend.hearing.repository;

import com.kalima.backend.casefile.repository.CaseFileRepository;
import com.kalima.backend.hearing.entity.Hearing;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

public interface HearingRepository extends JpaRepository<Hearing, UUID> {

    /**
     * Tenant-scoped primary-key lookup (see {@link CaseFileRepository#findScopedById}).
     */
    @EntityGraph(attributePaths = {"createdBy", "caseFile"})
    @Query("SELECT h FROM Hearing h WHERE h.id = :id")
    Optional<Hearing> findScopedById(@Param("id") UUID id);

    @EntityGraph(attributePaths = {"createdBy", "caseFile"})
    @Query("SELECT h FROM Hearing h WHERE h.caseFile.id = :caseId ORDER BY h.hearingDate DESC")
    Page<Hearing> findByCaseIdForList(@Param("caseId") UUID caseId, Pageable pageable);

    /**
     * All hearings in the tenant for {@code [start, end)} on non-archived cases.
     * Sort is supplied via {@code Pageable} (typically by {@code hearingDate} asc).
     */
    @EntityGraph(attributePaths = {
            "caseFile", "caseFile.client", "caseFile.assignedLawyer", "createdBy"
    })
    @Query("""
            SELECT h FROM Hearing h
            WHERE h.hearingDate >= :start
              AND h.hearingDate < :end
              AND h.caseFile.archivedAt IS NULL
            """)
    Page<Hearing> findOfficeHearingsForTimeRange(
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end,
            Pageable pageable);

    /**
     * Hearings on {@code [start, end)} whose parent case is not archived. Uses
     * the JVM default time zone for calendar-day interpretation (same as the
     * rest of the service layer for {@link LocalDateTime} fields).
     */
    @Query("""
            SELECT COUNT(h) FROM Hearing h
            WHERE h.hearingDate >= :start
              AND h.hearingDate < :end
              AND h.caseFile.archivedAt IS NULL
            """)
    long countHearingsForActiveCasesBetween(
            @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}
