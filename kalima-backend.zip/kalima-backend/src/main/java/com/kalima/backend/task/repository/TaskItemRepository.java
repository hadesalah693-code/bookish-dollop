package com.kalima.backend.task.repository;

import com.kalima.backend.domain.entity.DomainEnums;
import com.kalima.backend.task.entity.TaskItem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface TaskItemRepository extends JpaRepository<TaskItem, UUID> {

    @EntityGraph(attributePaths = {"createdBy", "assignedTo", "caseFile"})
    @Query("SELECT t FROM TaskItem t WHERE t.id = :id")
    Optional<TaskItem> findScopedById(@Param("id") UUID id);

    @EntityGraph(attributePaths = {"createdBy", "assignedTo", "caseFile"})
    @Query("""
            SELECT t FROM TaskItem t
            WHERE t.caseFile.id = :caseId
            ORDER BY t.dueDate ASC NULLS LAST, t.createdAt DESC
            """)
    Page<TaskItem> findByCaseIdForList(@Param("caseId") UUID caseId, Pageable pageable);

    @Query("""
            SELECT COUNT(t) FROM TaskItem t
            WHERE t.caseFile.archivedAt IS NULL
              AND t.status IN (:todo, :inProgress)
            """)
    long countPendingOnActiveCases(
            @Param("todo") DomainEnums.TaskStatus todo,
            @Param("inProgress") DomainEnums.TaskStatus inProgress);
}
