package com.kalima.backend.domain.entity;

public final class DomainEnums {

    private DomainEnums() {
    }

    public enum PersonType {
        INDIVIDUAL,
        COMPANY
    }

    public enum SystemRole {
        ADMIN,
        LAWYER,
        SENIOR_LAWYER,
        SECRETARY,
        ACCOUNTANT,
        CLIENT
    }

    public enum CaseStatus {
        NEW,
        IN_PROGRESS,
        ON_HOLD,
        CLOSED,
        ARCHIVED
    }

    public enum TaskPriority {
        LOW,
        MEDIUM,
        HIGH,
        URGENT
    }

    public enum TaskStatus {
        TODO,
        IN_PROGRESS,
        DONE,
        CANCELLED
    }

    public enum NotificationType {
        HEARING_ADDED,
        HEARING_UPDATED,
        CASE_STATUS_CHANGED,
        NEW_MESSAGE
    }

    /**
     * Role a {@link Person} plays inside a specific case. Separate from
     * {@link SystemRole} which describes the person's role in the firm.
     */
    public enum CaseParticipantRole {
        CLIENT,
        ASSIGNED_LAWYER,
        SECONDARY_LAWYER,
        OPPOSING_PARTY,
        WITNESS,
        EXPERT,
        JUDGE,
        COURT_OFFICIAL,
        THIRD_PARTY
    }
}
