package com.kalima.backend.auth.controller;

import com.kalima.backend.audit.AuditAction;
import com.kalima.backend.audit.service.AuditLogService;
import com.kalima.backend.auth.dto.LoginRequest;
import com.kalima.backend.auth.dto.LoginResponse;
import com.kalima.backend.auth.jwt.JwtService;
import com.kalima.backend.auth.ratelimit.LoginRateLimiter;
import com.kalima.backend.auth.support.EmailNormalization;
import com.kalima.backend.domain.entity.Person;
import com.kalima.backend.domain.repository.PersonRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    private final PersonRepository personRepository;
    private final AuditLogService auditLogService;
    private final LoginRateLimiter loginRateLimiter;

    public AuthController(AuthenticationManager authManager,
                          JwtService jwtService,
                          PersonRepository personRepository,
                          AuditLogService auditLogService,
                          LoginRateLimiter loginRateLimiter) {
        this.authManager = authManager;
        this.jwtService = jwtService;
        this.personRepository = personRepository;
        this.auditLogService = auditLogService;
        this.loginRateLimiter = loginRateLimiter;
    }

    @PostMapping("/login")
    @Transactional
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request,
                                               HttpServletRequest httpRequest) {
        String email = EmailNormalization.normalize(request.email());
        if (email == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "email is required");
        }
        if (!loginRateLimiter.allowLoginAttempt(httpRequest, email)) {
            throw new ResponseStatusException(
                    HttpStatus.TOO_MANY_REQUESTS,
                    "Too many login attempts. Please try again later.");
        }
        try {
            authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, request.password()));
        } catch (AuthenticationException ex) {
            // Look up the person by email so we can attach the correct tenant
            // to the audit record. Not found = no actor, no tenant (system-level).
            Person probed = personRepository.findByEmail(email).orElse(null);
            auditLogService.recordFailure(
                    AuditAction.LOGIN_FAILED,
                    probed,
                    email,
                    "Person",
                    probed != null ? probed.getId() : null,
                    Map.of("reason", classifyReason(probed)),
                    "Invalid email or password");
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }

        Person person = personRepository.findByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "Invalid email or password"));

        String token = jwtService.generateToken(person);
        person.setLastLoginAt(LocalDateTime.now());

        auditLogService.recordSuccess(
                AuditAction.LOGIN_SUCCESS,
                person,
                "Person",
                person.getId(),
                Map.of("role", person.getSystemRole().name()));

        return ResponseEntity.ok(new LoginResponse(
                token,
                "Bearer",
                jwtService.getExpiration(token),
                new LoginResponse.PersonInfo(
                        person.getId(),
                        person.getFullName(),
                        person.getEmail(),
                        person.getSystemRole())));
    }

    private String classifyReason(Person probed) {
        if (probed == null) {
            return "unknown_email";
        }
        if (!probed.isActive()) {
            return "account_disabled";
        }
        return "invalid_password";
    }
}
