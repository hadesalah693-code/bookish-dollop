package com.kalima.backend.hearing.service;

import com.kalima.backend.audit.AuditAction;
import com.kalima.backend.audit.service.AuditLogService;
import com.kalima.backend.auth.support.CurrentUserService;
import com.kalima.backend.casefile.dto.PartySummary;
import com.kalima.backend.casefile.entity.CaseFile;
import com.kalima.backend.domain.entity.Company;
import com.kalima.backend.domain.entity.DomainEnums;
import com.kalima.backend.domain.entity.Person;
import com.kalima.backend.casefile.repository.CaseFileRepository;
import com.kalima.backend.domain.repository.CompanyRepository;
import com.kalima.backend.domain.tenant.TenantContext;
import com.kalima.backend.hearing.dto.HearingCreateRequest;
import com.kalima.backend.hearing.entity.Hearing;
import com.kalima.backend.hearing.repository.HearingRepository;
import com.kalima.backend.hearing.dto.HearingOfficeItemResponse;
import com.kalima.backend.hearing.dto.HearingResponse;
import com.kalima.backend.hearing.dto.HearingUpdateRequest;
import com.kalima.backend.notification.service.NotificationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Hearings for a case: tenant-scoped, immutable {@code case_id} after create.
 */
@Service
@Transactional
public class HearingService {

    private final HearingRepository hearingRepository;
    private final CaseFileRepository caseFileRepository;
    private final CompanyRepository companyRepository;
    private final CurrentUserService currentUserService;
    private final AuditLogService auditLogService;
    private final NotificationService notificationService;

    public HearingService(HearingRepository hearingRepository,
                          CaseFileRepository caseFileRepository,
                          CompanyRepository companyRepository,
                          CurrentUserService currentUserService,
                          AuditLogService auditLogService,
                          NotificationService notificationService) {
        this.hearingRepository = hearingRepository;
        this.caseFileRepository = caseFileRepository;
        this.companyRepository = companyRepository;
        this.currentUserService = currentUserService;
        this.auditLogService = auditLogService;
        this.notificationService = notificationService;
    }

    public HearingResponse create(UUID caseId, HearingCreateRequest request) {
        CaseFile caseFile = loadCase(caseId);
        ensureCaseMutable(caseFile);
        Person creator = currentUserService.requireCurrentPerson();

        validateHearingWindow(request.hearingDate(), request.nextHearingDate());

        Hearing h = new Hearing();
        h.setCompany(currentTenantReference());
        h.setCaseFile(caseFile);
        h.setHearingDate(request.hearingDate());
        h.setCourtName(requireText(request.courtName(), "courtName"));
        h.setChamber(trimToNull(request.chamber()));
        h.setResult(trimToNull(request.result()));
        h.setNotes(trimToNull(request.notes()));
        h.setNextHearingDate(request.nextHearingDate());
        h.setCreatedBy(creator);

        Hearing saved = hearingRepository.save(h);
        auditLogService.recordSuccess(
                AuditAction.HEARING_CREATED,
                creator,
                "Hearing", saved.getId(),
                Map.of(
                        "caseId", caseId.toString(),
                        "hearingDate", saved.getHearingDate().toString(),
                        "courtName", saved.getCourtName()
                ));
        notificationService.notifyHearingScheduled(caseFile, saved, creator);
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public Page<HearingResponse> list(UUID caseId, Pageable pageable) {
        // Ensures 404 for unknown case in this tenant
        CaseFile caseFile = loadCase(caseId);
        ensureClientCanAccessCase(caseFile);
        return hearingRepository
                .findByCaseIdForList(caseId, pageable)
                .map(this::toResponse);
    }

    /**
     * Per-tenant list of hearings on a given calendar day (default: today), only
     * for cases that are not archived. Aligns with {@code /api/dashboard/summary}
     * day boundaries ({@code date.atStartOfDay()} to {@code date+1.atStartOfDay()}).
     */
    @Transactional(readOnly = true)
    public Page<HearingOfficeItemResponse> listForOfficeOnDate(
            LocalDate date, Pageable pageable) {
        LocalDate d = date == null ? LocalDate.now() : date;
        LocalDateTime start = d.atStartOfDay();
        LocalDateTime end = d.plusDays(1).atStartOfDay();
        return hearingRepository
                .findOfficeHearingsForTimeRange(start, end, pageable)
                .map(this::toOfficeItem);
    }

    @Transactional(readOnly = true)
    public HearingResponse findById(UUID caseId, UUID hearingId) {
        Hearing h = loadHearingInCase(caseId, hearingId);
        ensureClientCanAccessCase(h.getCaseFile());
        return toResponse(h);
    }

    public HearingResponse update(UUID caseId, UUID hearingId, HearingUpdateRequest request) {
        Hearing h = loadHearingInCase(caseId, hearingId);
        ensureCaseMutable(h.getCaseFile());
        Person actor = currentUserService.requireCurrentPerson();

        validateHearingWindow(request.hearingDate(), request.nextHearingDate());

        h.setHearingDate(request.hearingDate());
        h.setCourtName(requireText(request.courtName(), "courtName"));
        h.setChamber(trimToNull(request.chamber()));
        h.setResult(trimToNull(request.result()));
        h.setNotes(trimToNull(request.notes()));
        h.setNextHearingDate(request.nextHearingDate());

        auditLogService.recordSuccess(
                AuditAction.HEARING_UPDATED,
                actor,
                "Hearing", h.getId(),
                Map.of(
                        "caseId", caseId.toString(),
                        "hearingDate", h.getHearingDate().toString()
                ));
        notificationService.notifyHearingUpdated(h.getCaseFile(), h, actor);
        return toResponse(h);
    }

    // ----- helpers ----------------------------------------------------------

    private Hearing loadHearingInCase(UUID caseId, UUID hearingId) {
        Hearing h = hearingRepository.findScopedById(hearingId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Hearing not found: " + hearingId));
        if (!h.getCaseFile().getId().equals(caseId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Hearing not found for case " + caseId);
        }
        return h;
    }

    private CaseFile loadCase(UUID caseId) {
        return caseFileRepository.findScopedById(caseId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Case not found: " + caseId));
    }

    /**
     * Clients may only read hearings for cases where they are the primary client.
     */
    private void ensureClientCanAccessCase(CaseFile caseFile) {
        Person actor = currentUserService.requireCurrentPerson();
        if (actor.getSystemRole() == DomainEnums.SystemRole.CLIENT
                && !caseFile.getClient().getId().equals(actor.getId())) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Case not found: " + caseFile.getId());
        }
    }

    private void ensureCaseMutable(CaseFile c) {
        if (c.getArchivedAt() != null) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Cannot add or edit hearings for an archived case.");
        }
    }

    private void validateHearingWindow(
            java.time.LocalDateTime hearingDate,
            java.time.LocalDateTime nextHearingDate) {
        if (nextHearingDate == null) {
            return;
        }
        if (nextHearingDate.isBefore(hearingDate)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "nextHearingDate must not be before hearingDate");
        }
    }

    private Company currentTenantReference() {
        return companyRepository.getReferenceById(TenantContext.getRequired());
    }

    private HearingResponse toResponse(Hearing h) {
        Person createdBy = h.getCreatedBy();
        PartySummary party = toParty(createdBy);
        return new HearingResponse(
                h.getId(),
                h.getCaseFile().getId(),
                h.getHearingDate(),
                h.getCourtName(),
                h.getChamber(),
                h.getResult(),
                h.getNotes(),
                h.getNextHearingDate(),
                party,
                h.getCreatedAt(),
                h.getUpdatedAt()
        );
    }

    private HearingOfficeItemResponse toOfficeItem(Hearing h) {
        CaseFile c = h.getCaseFile();
        return new HearingOfficeItemResponse(
                h.getId(),
                c.getId(),
                c.getCaseNumber(),
                c.getTitle(),
                h.getHearingDate(),
                h.getCourtName(),
                h.getChamber(),
                h.getResult(),
                h.getNotes(),
                toParty(c.getClient()),
                toParty(c.getAssignedLawyer()),
                toParty(h.getCreatedBy()),
                h.getCreatedAt()
        );
    }

    private static PartySummary toParty(Person person) {
        if (person == null) {
            return null;
        }
        return new PartySummary(
                person.getId(), person.getFullName(), person.getSystemRole());
    }

    private static String requireText(String value, String field) {
        String t = trimToNull(value);
        if (t == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, field + " is required");
        }
        return t;
    }

    private static String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
