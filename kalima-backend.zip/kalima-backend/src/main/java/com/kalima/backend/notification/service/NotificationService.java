package com.kalima.backend.notification.service;

import com.kalima.backend.auth.support.CurrentUserService;
import com.kalima.backend.casefile.entity.CaseFile;
import com.kalima.backend.domain.entity.Company;
import com.kalima.backend.domain.entity.DomainEnums;
import com.kalima.backend.domain.entity.Person;
import com.kalima.backend.hearing.entity.Hearing;
import com.kalima.backend.notification.entity.Notification;
import com.kalima.backend.notification.repository.NotificationRepository;
import com.kalima.backend.notification.dto.NotificationResponse;
import com.kalima.backend.notification.dto.UnreadCountResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

@Service
@Transactional
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final CurrentUserService currentUserService;

    public NotificationService(NotificationRepository notificationRepository,
                               CurrentUserService currentUserService) {
        this.notificationRepository = notificationRepository;
        this.currentUserService = currentUserService;
    }

    @Transactional(readOnly = true)
    public Page<NotificationResponse> listForCurrentUser(Pageable pageable) {
        UUID me = currentUserService.requireCurrentPerson().getId();
        return notificationRepository
                .findByRecipientId(me, pageable)
                .map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public UnreadCountResponse unreadCount() {
        UUID me = currentUserService.requireCurrentPerson().getId();
        return new UnreadCountResponse(
                notificationRepository.countByRecipientUser_IdAndReadIsFalse(me));
    }

    public void markRead(UUID id) {
        Person me = currentUserService.requireCurrentPerson();
        Notification n = notificationRepository
                .findByIdForRecipient(id, me.getId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Notification not found: " + id));
        if (!n.isRead()) {
            n.setRead(true);
            n.setReadAt(LocalDateTime.now());
        }
    }

    public int markAllRead() {
        UUID me = currentUserService.requireCurrentPerson().getId();
        return notificationRepository.markAllReadForRecipient(
                me, LocalDateTime.now());
    }

    // ----- internal: domain event hooks -----------------------------------

    public void notifyHearingScheduled(CaseFile caseFile, Hearing saved, Person actor) {
        Objects.requireNonNull(caseFile, "caseFile");
        Objects.requireNonNull(saved, "hearing");
        Person target = caseFile.getAssignedLawyer() != null
                ? caseFile.getAssignedLawyer()
                : caseFile.getClient();
        if (target.getId().equals(actor.getId())) {
            return;
        }
        String title = "جلسة جديدة";
        String body = "قضية " + caseFile.getCaseNumber() + " — " + saved.getHearingDate();
        persist(
                caseFile.getCompany(),
                target,
                caseFile,
                DomainEnums.NotificationType.HEARING_ADDED,
                title,
                body);
    }

    public void notifyHearingUpdated(CaseFile caseFile, Hearing h, Person actor) {
        Person target = caseFile.getAssignedLawyer() != null
                ? caseFile.getAssignedLawyer()
                : caseFile.getClient();
        if (target.getId().equals(actor.getId())) {
            return;
        }
        String title = "تحديث جلسة";
        String body = "قضية " + caseFile.getCaseNumber() + " — " + h.getHearingDate();
        persist(
                caseFile.getCompany(),
                target,
                caseFile,
                DomainEnums.NotificationType.HEARING_UPDATED,
                title,
                body);
    }

    public void notifyCaseStatusChanged(
            CaseFile c,
            DomainEnums.CaseStatus oldStatus,
            Person actor) {
        Person client = c.getClient();
        if (client.getId().equals(actor.getId())) {
            return;
        }
        String title = "تغيير حالة قضية";
        String body = c.getCaseNumber() + ": " + oldStatus.name() + " → " + c.getStatus().name();
        persist(
                c.getCompany(),
                client,
                c,
                DomainEnums.NotificationType.CASE_STATUS_CHANGED,
                title,
                body);
    }

    private void persist(
            Company company,
            Person recipient,
            CaseFile caseFile,
            DomainEnums.NotificationType type,
            String title,
            String body) {
        Notification n = new Notification();
        n.setCompany(company);
        n.setRecipientUser(recipient);
        n.setCaseFile(caseFile);
        n.setType(type);
        n.setTitle(title);
        n.setBody(body);
        n.setRead(false);
        notificationRepository.save(n);
    }

    private NotificationResponse toResponse(Notification n) {
        return new NotificationResponse(
                n.getId(),
                n.getType(),
                n.getTitle(),
                n.getBody(),
                n.isRead(),
                n.getCaseFile() != null ? n.getCaseFile().getId() : null,
                n.getCreatedAt());
    }
}
