package com.kalima.backend.audit;

/**
 * Canonical names for audited actions. Stored verbatim in
 * {@code audit_logs.action}; treat renames as a breaking change for anyone
 * querying history. New values can be added freely.
 */
public final class AuditAction {

    private AuditAction() {
    }

    // Authentication
    public static final String LOGIN_SUCCESS       = "LOGIN_SUCCESS";
    public static final String LOGIN_FAILED        = "LOGIN_FAILED";

    // Staff lifecycle
    public static final String STAFF_CREATED       = "STAFF_CREATED";
    public static final String STAFF_UPDATED       = "STAFF_UPDATED";
    public static final String STAFF_DISABLED      = "STAFF_DISABLED";
    public static final String STAFF_ENABLED       = "STAFF_ENABLED";
    public static final String PASSWORD_CHANGED    = "PASSWORD_CHANGED";
    public static final String PASSWORD_RESET      = "PASSWORD_RESET";

    // Person (clients)
    public static final String PERSON_CREATED      = "PERSON_CREATED";
    public static final String PERSON_UPDATED      = "PERSON_UPDATED";
    public static final String PERSON_DELETED      = "PERSON_DELETED";
    public static final String PERSON_ARCHIVED     = "PERSON_ARCHIVED";

    // Cases
    public static final String CASE_CREATED        = "CASE_CREATED";
    public static final String CASE_UPDATED        = "CASE_UPDATED";
    public static final String CASE_STATUS_CHANGED = "CASE_STATUS_CHANGED";
    public static final String CASE_ARCHIVED       = "CASE_ARCHIVED";
    public static final String CASE_RESTORED       = "CASE_RESTORED";

    // Case participants
    public static final String PARTICIPANT_ADDED   = "PARTICIPANT_ADDED";
    public static final String PARTICIPANT_REMOVED = "PARTICIPANT_REMOVED";

    // Hearings
    public static final String HEARING_CREATED      = "HEARING_CREATED";
    public static final String HEARING_UPDATED      = "HEARING_UPDATED";

    // Tasks
    public static final String TASK_CREATED           = "TASK_CREATED";
    public static final String TASK_UPDATED           = "TASK_UPDATED";
}
