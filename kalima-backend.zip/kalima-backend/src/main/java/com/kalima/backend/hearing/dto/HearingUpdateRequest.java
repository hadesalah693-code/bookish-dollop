package com.kalima.backend.hearing.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

/**
 * Full replacement body for {@code PUT} on a hearing (same fields as create).
 */
public record HearingUpdateRequest(
        @NotNull(message = "hearingDate is required")
        LocalDateTime hearingDate,

        @NotBlank(message = "courtName is required")
        @Size(max = 200, message = "courtName must be at most 200 characters")
        String courtName,

        @Size(max = 100, message = "chamber must be at most 100 characters")
        String chamber,

        String result,
        String notes,

        LocalDateTime nextHearingDate
) {
}
