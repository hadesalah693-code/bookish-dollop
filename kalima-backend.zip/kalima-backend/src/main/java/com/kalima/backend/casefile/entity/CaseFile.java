package com.kalima.backend.casefile.entity;

import com.kalima.backend.domain.entity.BaseAuditEntity;
import com.kalima.backend.domain.entity.Company;
import com.kalima.backend.domain.entity.DomainEnums;
import com.kalima.backend.domain.entity.Person;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Filter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * A legal case file (matter).
 *
 * <p><b>Primary parties</b> are modelled as direct FKs for query speed:
 * {@code client}, {@code assignedLawyer}, {@code createdBy}. When richer
 * participant roles are needed later (secondary lawyers, opposing counsel,
 * consultants …), introduce a {@code case_participants(case_id, person_id,
 * role)} join table — the direct FKs remain as denormalised shortcuts for the
 * <em>primary</em> client and lawyer. No existing API needs to change.
 *
 * <p><b>Archive</b>: {@link #archivedAt} is the soft-delete marker.
 * {@link #status} = {@code ARCHIVED} stays in sync. Restoring clears
 * {@code archivedAt} and sets the status back to {@code CLOSED}.
 */
@Entity
@Table(name = "cases")
@Getter
@Setter
@NoArgsConstructor
@Filter(name = "tenantFilter", condition = "company_id = :companyId")
public class CaseFile extends BaseAuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "company_id", nullable = false, updatable = false)
    private Company company;

    // Uniqueness is composite (company_id, case_number); see V9 migration.
    @Column(name = "case_number", nullable = false, length = 100)
    private String caseNumber;

    @Column(name = "court_case_number", length = 100)
    private String courtCaseNumber;

    @Column(name = "title", nullable = false, length = 250)
    private String title;

    @Column(name = "description")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private DomainEnums.CaseStatus status;

    @Column(name = "case_type", length = 100)
    private String caseType;

    /** Display name of the primary court (case-level, not a specific session). */
    @Column(name = "court_name", length = 200)
    private String courtName;

    /** Judicial circuit / chamber label for the file (مثلاً: الدائرة). */
    @Column(name = "court_circuit", length = 100)
    private String courtCircuit;

    /** Current stage of the proceedings (e.g. استئناف، أول درجة). */
    @Column(name = "procedure_stage", length = 100)
    private String procedureStage;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "close_date")
    private LocalDate closeDate;

    @Column(name = "archived_at")
    private LocalDateTime archivedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_id", nullable = false)
    private Person client;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_lawyer_id")
    private Person assignedLawyer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by", nullable = false)
    private Person createdBy;

    @PrePersist
    void ensureTenant() {
        if (this.company == null) {
            throw new IllegalStateException(
                    "CaseFile.company must be set before persist.");
        }
    }
}
