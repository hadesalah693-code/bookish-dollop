package com.kalima.backend.auth.seed;

import com.kalima.backend.domain.entity.Company;
import com.kalima.backend.domain.entity.DomainEnums;
import com.kalima.backend.domain.entity.Person;
import com.kalima.backend.domain.repository.CompanyRepository;
import com.kalima.backend.domain.repository.PersonRepository;
import com.kalima.backend.domain.tenant.TenantContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * DEV-only seeder: makes the local environment reproducible by ensuring the
 * default tenant + admin, and a second tenant + admin used by multi-tenancy
 * tests. Fully idempotent — safe to run on every startup.
 */
@Component
@Profile("dev")
public class AdminSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(AdminSeeder.class);

    // Default tenant (company row seeded by Flyway V5).
    private static final String DEFAULT_ADMIN_EMAIL = "admin@kalima.local";
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";

    // Second tenant for cross-tenant isolation testing. Fixed UUID so E2E
    // scripts and DB snapshots stay stable across resets.
    private static final UUID SECOND_COMPANY_ID =
            UUID.fromString("5b4bbf78-abef-4483-aad4-5ef81cc7ba9e");
    private static final String SECOND_COMPANY_NAME = "Tenant Two";
    private static final String SECOND_ADMIN_EMAIL = "admin2@kalima.local";
    private static final String SECOND_ADMIN_PASSWORD = "admin123";

    private final PersonRepository personRepository;
    private final CompanyRepository companyRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminSeeder(PersonRepository personRepository,
                       CompanyRepository companyRepository,
                       PasswordEncoder passwordEncoder) {
        this.personRepository = personRepository;
        this.companyRepository = companyRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        seedDefaultTenantAdmin();
        seedSecondTenantAndAdmin();
    }

    private void seedDefaultTenantAdmin() {
        TenantContext.set(Company.DEFAULT_ID);
        try {
            Company defaultCompany = companyRepository.findById(Company.DEFAULT_ID)
                    .orElseThrow(() -> new IllegalStateException(
                            "Default company " + Company.DEFAULT_ID + " not found. "
                            + "Migration V5 should have seeded it."));
            ensureAdmin(defaultCompany, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD,
                    "System Admin");
        } finally {
            TenantContext.clear();
        }
    }

    private void seedSecondTenantAndAdmin() {
        TenantContext.set(SECOND_COMPANY_ID);
        try {
            Company company = companyRepository.findById(SECOND_COMPANY_ID)
                    .orElseGet(() -> {
                        Company c = new Company();
                        c.setId(SECOND_COMPANY_ID);
                        c.setName(SECOND_COMPANY_NAME);
                        c.setActive(true);
                        Company saved = companyRepository.save(c);
                        log.warn("[DEV] Seeded second tenant company: id={} name={}",
                                saved.getId(), saved.getName());
                        return saved;
                    });
            ensureAdmin(company, SECOND_ADMIN_EMAIL, SECOND_ADMIN_PASSWORD,
                    "Tenant Two Admin");
        } finally {
            TenantContext.clear();
        }
    }

    private void ensureAdmin(Company company, String email, String password, String fullName) {
        if (personRepository.findByEmail(email).isPresent()) {
            return;
        }
        Person admin = new Person();
        admin.setCompany(company);
        admin.setPersonType(DomainEnums.PersonType.INDIVIDUAL);
        admin.setSystemRole(DomainEnums.SystemRole.ADMIN);
        admin.setFullName(fullName);
        admin.setEmail(email);
        admin.setPasswordHash(passwordEncoder.encode(password));
        admin.setActive(true);
        personRepository.save(admin);
        log.warn("[DEV] Seeded admin: {} / {} (company: {})",
                email, password, company.getName());
    }
}
