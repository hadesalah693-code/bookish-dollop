package com.kalima.backend.auth.support;

import com.kalima.backend.domain.entity.Person;
import com.kalima.backend.domain.repository.PersonRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/**
 * Resolves the currently-authenticated {@link Person} from the Spring
 * SecurityContext. The JWT filter populates the principal name with the
 * person's email, so a single lookup by email is enough.
 */
@Service
public class CurrentUserService {

    private final PersonRepository personRepository;

    public CurrentUserService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public Person requireCurrentPerson() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth.getName() == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                    "Authentication required");
        }
        String email = EmailNormalization.normalize(auth.getName());
        if (email == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                    "Authentication required");
        }
        return personRepository.findByEmail(email)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "Authenticated person not found for email: " + email));
    }
}
