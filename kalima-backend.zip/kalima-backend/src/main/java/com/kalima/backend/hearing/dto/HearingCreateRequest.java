package com.kalima.backend.hearing.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

/**
 * Request body for creating a {@link com.kalima.backend.hearing.entity.Hearing}
 * under a case.
 */
public record HearingCreateRequest(
        @NotNull(message = "hearingDate is required")
        LocalDateTime hearingDate,

        @NotBlank(message = "courtName is required")
        @Size(max = 200, message = "courtName must be at most 200 characters")
        String courtName,

        @Size(max = 100, message = "chamber must be at most 100 characters")
        String chamber,

        String result,
        String notes,

        LocalDateTime nextHearingDate
) {
}
