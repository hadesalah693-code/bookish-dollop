package com.kalima.backend.task.service;

import com.kalima.backend.audit.AuditAction;
import com.kalima.backend.audit.service.AuditLogService;
import com.kalima.backend.auth.support.CurrentUserService;
import com.kalima.backend.casefile.dto.PartySummary;
import com.kalima.backend.casefile.entity.CaseFile;
import com.kalima.backend.domain.entity.Company;
import com.kalima.backend.domain.entity.Person;
import com.kalima.backend.casefile.repository.CaseFileRepository;
import com.kalima.backend.domain.repository.CompanyRepository;
import com.kalima.backend.domain.repository.PersonRepository;
import com.kalima.backend.domain.tenant.TenantContext;
import com.kalima.backend.task.entity.TaskItem;
import com.kalima.backend.task.repository.TaskItemRepository;
import com.kalima.backend.task.dto.TaskCreateRequest;
import com.kalima.backend.task.dto.TaskResponse;
import com.kalima.backend.task.dto.TaskUpdateRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;
import java.util.UUID;

/**
 * Case-scoped tasks; tenant isolation matches {@link com.kalima.backend.hearing.service.HearingService}.
 */
@Service
@Transactional
public class TaskService {

    private final TaskItemRepository taskItemRepository;
    private final CaseFileRepository caseFileRepository;
    private final CompanyRepository companyRepository;
    private final PersonRepository personRepository;
    private final CurrentUserService currentUserService;
    private final AuditLogService auditLogService;

    public TaskService(TaskItemRepository taskItemRepository,
                       CaseFileRepository caseFileRepository,
                       CompanyRepository companyRepository,
                       PersonRepository personRepository,
                       CurrentUserService currentUserService,
                       AuditLogService auditLogService) {
        this.taskItemRepository = taskItemRepository;
        this.caseFileRepository = caseFileRepository;
        this.companyRepository = companyRepository;
        this.personRepository = personRepository;
        this.currentUserService = currentUserService;
        this.auditLogService = auditLogService;
    }

    public TaskResponse create(UUID caseId, TaskCreateRequest request) {
        CaseFile caseFile = loadCase(caseId);
        ensureCaseMutable(caseFile);
        Person creator = currentUserService.requireCurrentPerson();
        Person assignee = resolveAssignee(request.assignedToId());

        TaskItem t = new TaskItem();
        t.setCompany(currentTenantReference());
        t.setCaseFile(caseFile);
        t.setTitle(requireText(request.title(), "title"));
        t.setDescription(trimToNull(request.description()));
        t.setPriority(request.priority());
        t.setStatus(request.status());
        t.setDueDate(request.dueDate());
        t.setAssignedTo(assignee);
        t.setCreatedBy(creator);

        TaskItem saved = taskItemRepository.save(t);
        auditLogService.recordSuccess(
                AuditAction.TASK_CREATED,
                creator,
                "TaskItem", saved.getId(),
                Map.of(
                        "caseId", caseId.toString(),
                        "title", saved.getTitle(),
                        "status", saved.getStatus().name()
                ));
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public Page<TaskResponse> list(UUID caseId, Pageable pageable) {
        loadCase(caseId);
        return taskItemRepository.findByCaseIdForList(caseId, pageable).map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public TaskResponse findById(UUID caseId, UUID taskId) {
        TaskItem t = loadTaskInCase(caseId, taskId);
        return toResponse(t);
    }

    public TaskResponse update(UUID caseId, UUID taskId, TaskUpdateRequest request) {
        TaskItem t = loadTaskInCase(caseId, taskId);
        ensureCaseMutable(t.getCaseFile());
        Person actor = currentUserService.requireCurrentPerson();
        Person assignee = resolveAssignee(request.assignedToId());

        t.setTitle(requireText(request.title(), "title"));
        t.setDescription(trimToNull(request.description()));
        t.setPriority(request.priority());
        t.setStatus(request.status());
        t.setDueDate(request.dueDate());
        t.setAssignedTo(assignee);

        auditLogService.recordSuccess(
                AuditAction.TASK_UPDATED,
                actor,
                "TaskItem", t.getId(),
                Map.of(
                        "caseId", caseId.toString(),
                        "status", t.getStatus().name()
                ));
        return toResponse(t);
    }

    private TaskItem loadTaskInCase(UUID caseId, UUID taskId) {
        TaskItem t = taskItemRepository.findScopedById(taskId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Task not found: " + taskId));
        if (!t.getCaseFile().getId().equals(caseId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Task not found for case " + caseId);
        }
        return t;
    }

    private CaseFile loadCase(UUID caseId) {
        return caseFileRepository.findScopedById(caseId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Case not found: " + caseId));
    }

    private void ensureCaseMutable(CaseFile c) {
        if (c.getArchivedAt() != null) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Cannot add or edit tasks for an archived case.");
        }
    }

    private Person resolveAssignee(UUID assignedToId) {
        if (assignedToId == null) {
            return null;
        }
        Person p = personRepository.findScopedById(assignedToId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "assignedTo not found in this company: " + assignedToId));
        if (!p.isActive()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "assignedTo is inactive: " + assignedToId);
        }
        if (p.getArchivedAt() != null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Cannot assign task to an archived person: " + assignedToId);
        }
        return p;
    }

    private Company currentTenantReference() {
        return companyRepository.getReferenceById(TenantContext.getRequired());
    }

    private TaskResponse toResponse(TaskItem t) {
        Person createdBy = t.getCreatedBy();
        PartySummary createdParty = new PartySummary(
                createdBy.getId(), createdBy.getFullName(), createdBy.getSystemRole());
        Person at = t.getAssignedTo();
        PartySummary assigneeParty = at == null
                ? null
                : new PartySummary(at.getId(), at.getFullName(), at.getSystemRole());
        return new TaskResponse(
                t.getId(),
                t.getCaseFile().getId(),
                t.getTitle(),
                t.getDescription(),
                t.getPriority(),
                t.getStatus(),
                t.getDueDate(),
                assigneeParty,
                createdParty,
                t.getCreatedAt(),
                t.getUpdatedAt()
        );
    }

    private static String requireText(String value, String field) {
        String x = trimToNull(value);
        if (x == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, field + " is required");
        }
        return x;
    }

    private static String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
